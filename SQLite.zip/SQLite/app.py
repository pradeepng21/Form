from flask import Flask
from flask import render_template, request
import sqlite3
import numpy as np

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/submit', methods = ['POST', 'GET'])
def details():
    if request.method == 'POST':
        name = request.form.get('Name')
        email = request.form.get('email')
        address = request.form.get('Address')
        city = request.form.get('City')
        Zipcode = request.form.get('Zipcode')
    connection = sqlite3.connect("C:\\Users\\Pradeep_NG\\Documents\\Source_Codes\\intern\\SQLite\\task2.db")
    cur = connection.cursor()
    def insert(name, email, address, city, zipcode):
        q = "insert into Details(Name, email, Address, City, Zipcode) values(?, ?, ?, ?, ?);"
        connection.execute(q,(name, email, address, city, zipcode))
        connection.commit()
        # q2 = "select * from Details;" 
        # b = connection.execute(q2)
        # d = list(b)
        connection.close()
    insert(name, email, address, city, Zipcode)    
    return render_template('success.html', n = name, e = email, a = address, c = city, z = Zipcode)


if __name__ == "__main__":
    app.run(debug=True)
